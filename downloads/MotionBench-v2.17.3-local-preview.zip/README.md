# MotionBench 2.17.3-local 图表修正版

打开 MotionBench.html；当前仍是离线 HTML 工作台，尚未创建 Windows 安装包。
原完整 FVP、弹性框架及下方冲刺 FVP 保留；收起能力四卡不会隐藏三图区。

实际整区截图对照见 docs/chart-restore-comparison-2.17.3.md，8 张 PNG 在 downloads/chart-restore-2.17.3/。
版本与数据回退边界见 docs/chart-restore-2.17.3.md，当前实际验收见 docs/acceptance-2.17.3-local.json。
Windows 应用分阶段方案见 docs/windows-app-plan.md。

本包不含运动员数据，所有截图均为合成记录。HTML 的嵌入记录为 null。
在新文件路径打开应用会使用独立数据库；请从原应用导出 JSONL 备份再通过应用导入。
替换 HTML 不等于迁移或回滚数据；本轮没有读取或迁移真实数据库。

HTML SHA256：5a9d9d4a742878be8e258a58a68238a77a4e5c0f26898090e34d3ed8e0e67854
不可变源码标签：https://github.com/ZekeNiu/MotionBench/tree/review-v2.17.3-chart-restore-20261010
官方下载校验说明：https://github.com/ZekeNiu/MotionBench/blob/review-v2.17.3-chart-restore-20261010/downloads/README.md
旧版回退标签：https://github.com/ZekeNiu/MotionBench/tree/review-rollback-v2.17.2-before-chart-restore-20261010
